I
-- Insert statements for Book class

INSERT INTO Book VALUES(NULL, 'The Great Gatsby', '9780743273565', 'F. Scott Fitzgerald', 12.99);
INSERT INTO Book VALUES(NULL, 'To Kill a Mockingbird', '9780061120084', 'Harper Lee', 10.99);
INSERT INTO Book VALUES(NULL, 'Pride and Prejudice', '9780141439518', 'Jane Austen', 9.99);
INSERT INTO Book VALUES(NULL, '1984', '9780451524935', 'George Orwell', 11.99);
INSERT INTO Book VALUES(NULL, 'The Catcher in the Rye', '9780316769488', 'J.D. Salinger', 8.99);
